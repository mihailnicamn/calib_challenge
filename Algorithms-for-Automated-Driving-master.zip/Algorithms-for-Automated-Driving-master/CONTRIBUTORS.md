# Contributors
The initial version of this book, which contained the chapters on lane detection and control, was written by [Mario Theers](https://github.com/homasfermi).
The chapter on camera calibration was written by [Mankaran Singh](https://github.com/MankaranSingh), with minor contributions from [Mario Theers](https://github.com/homasfermi).