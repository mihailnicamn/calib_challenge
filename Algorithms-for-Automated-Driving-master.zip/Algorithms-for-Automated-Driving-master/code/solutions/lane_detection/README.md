The following files are provided with the course and it is **not** expected that the student/reader would write them as part of the exercises:

* `collect_data.py`
* `camera_geometry_numba.py` : You can import the `CameraGeometry` class from this file instead of importing it from `camera_geometry.py`. This will lead to a speed-up due to [numba](http://numba.pydata.org/)